# `Creating traces/spans`

::: agents.tracing.create
