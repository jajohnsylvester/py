# `OpenAI TTS`

::: agents.voice.models.openai_tts
